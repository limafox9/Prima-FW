

#ifndef INC__VER_H_
#define INC__VER_H_

#define FW_VERSION_MAJOR 	1
#define FW_VERSION_MINOR 	0
#define FW_VERSION_REVISION 2

#endif /* INC__VER_H_ */
