/*==============================================================================

Filename: printer.h

Created on: Jan 27, 2023

Original work: Copyright (c) 2023 Luca Favenzi
Modified work:

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Visit www.favenzi.it
      luca@favenzi.it

================================================================================
PURPOSE:
USAGE:
==============================================================================*/



#ifndef INC_PRINTER_H_
#define INC_PRINTER_H_

#include "time.h"

void Print(const char* format, ...);
void PrintLF(uint8_t lines);
void PrintDivisor();
void PrinterInit();
void PrintSize(uint8_t width, uint8_t height);
void PrintStepLine(const char* step, float t1, float t2, float pressure, RTCTimerTime_s* time);
void PrintHeader (const char* title, float t1, uint16_t dryTime, uint16_t sterilTime, RTCDateTime_s* time);
void PrintFooter (const char* result, RTCDateTime_s* time, RTCTimerTime_s* timer);
void PrintTestPage();
void PrintPowerTestHeader();
void PrintSettings();

#endif /* INC_PRINTER_H_ */
