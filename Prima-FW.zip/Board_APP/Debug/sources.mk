################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
OBJCOPY_HEX := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 
OBJCOPY_BIN := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Core/Devs \
Core/Src \
Core/Startup \
Drivers/STM32F1xx_HAL_Driver/Src \
FATFS/App \
Middlewares/ST/STM32_USB_Host_Library/Class/MSC/Src \
Middlewares/ST/STM32_USB_Host_Library/Core/Src \
Middlewares/Third_Party/FatFs/src \
Middlewares/Third_Party/FatFs/src/drivers \
Middlewares/Third_Party/FatFs/src/option \
Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS \
Middlewares/Third_Party/FreeRTOS/Source \
Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3 \
Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang \
USB_HOST/App \
USB_HOST/Target \

