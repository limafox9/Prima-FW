Core/Devs/AD7705.o: ../Core/Devs/AD7705.c
