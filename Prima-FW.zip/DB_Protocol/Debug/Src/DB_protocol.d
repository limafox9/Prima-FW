Src/DB_protocol.o: ../Src/DB_protocol.c ../Inc/crc.h ../Inc/DB_Protocol.h
../Inc/crc.h:
../Inc/DB_Protocol.h:
